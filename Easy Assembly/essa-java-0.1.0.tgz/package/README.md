# esa — simple package manager/installer

This repository adds a minimal `esa` CLI to manage small local packages for Easy Assembly.

Usage (from workspace root):

```
node bin/esa.js list
node bin/esa.js install sample-package
node bin/esa.js installed
node bin/esa.js uninstall sample-package
```

Files created:
- `bin/esa.js` — CLI script
- `registry/` — local package registry (sample packages)
- `esa_modules/` — where packages are installed

Install via npm (publish steps required):

```
# pack locally and test
npm pack
npm i -g ./essa-java-0.1.0.tgz

# or publish to npm (you must be logged in with `npm login`)
npm publish

# then users can install with
npm i -g essa-java
```
